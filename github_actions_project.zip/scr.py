import os
import zipfile

def create_github_actions_project():
    package_path = "com/browser/multi"
    package_name = "com.browser.multi"
    
    # 1. Структура папок (Стандарт Android + GitHub Workflow)
    folders = [
        'app/src/main/java/' + package_path,
        'app/src/main/res/layout',
        'app/src/main/res/values',
        '.github/workflows'
    ]
    for folder in folders:
        os.makedirs(folder, exist_ok=True)

    # 2. GitHub Actions Workflow (Скрипт сборки)
    # Этот файл скажет Гитхабу: "Возьми Java, собери APK и дай мне ссылку"
    workflow_content = '''
name: Build Android APK
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: set up JDK 17
        uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Grant execute permission for gradlew
        run: chmod +x gradlew

      - name: Build with Gradle
        run: ./gradlew assembleDebug

      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: my-browser-apk
          path: app/build/outputs/apk/debug/app-debug.apk
'''
    with open('.github/workflows/android.yml', 'w', encoding='utf-8') as f:
        f.write(workflow_content.strip())

    # 3. Файлы проекта (Gradle)
    with open('settings.gradle', 'w') as f:
        f.write("include ':app'")

    with open('build.gradle', 'w') as f:
        f.write("buildscript { repositories { google(); mavenCentral() }; dependencies { classpath 'com.android.tools.build:gradle:7.4.2' } }\n"
                "allprojects { repositories { google(); mavenCentral() } }")

    with open('app/build.gradle', 'w') as f:
        f.write(f'''
apply plugin: 'com.android.application'
android {{
    namespace '{package_name}'
    compileSdk 33
    defaultConfig {{
        applicationId "{package_name}"
        minSdk 24
        targetSdk 33
        versionCode 1
        versionName "1.0"
    }}
}}
dependencies {{
    implementation 'androidx.appcompat:appcompat:1.6.1'
}}''')

    # 4. MainActivity.java (Браузер с изоляцией сессий)
    java_code = f'''package {package_name};
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {{
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        
        // Магия сессий: чистим куки при старте
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl("https://whoer.net");
    }}
}}'''
    with open(f'app/src/main/java/{package_path}/MainActivity.java', 'w') as f:
        f.write(java_code)

    # 5. AndroidManifest.xml
    manifest = f'''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application android:label="MultiBrowser" android:theme="@style/Theme.AppCompat.Light.NoActionBar" android:usesCleartextTraffic="true">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>'''
    with open('app/src/main/AndroidManifest.xml', 'w') as f:
        f.write(manifest)

    # 6. ВАЖНО: Настоящий gradlew (простейший скрипт-обертка)
    with open('gradlew', 'w', newline='\n') as f:
        f.write('#!/bin/sh\nexec gradle "$@"\n')

    # Создаем ZIP
    zip_name = 'github_actions_project.zip'
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            for file in files:
                if file == zip_name or file == __file__: continue
                path = os.path.join(root, file)
                zipf.write(path, os.path.relpath(path, '.'))

    print(f"🚀 Проект для GitHub готов: {zip_name}")

create_github_actions_project()
